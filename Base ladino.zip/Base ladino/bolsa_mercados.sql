-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3307
-- Tiempo de generación: 04-11-2026 a las 17:11:49
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bolsa_mercados`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `activos`
--

CREATE TABLE `activos` (
  `id_activo` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `simbolo` varchar(20) DEFAULT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  `id_mercado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `activos`
--

INSERT INTO `activos` (`id_activo`, `nombre`, `tipo`, `simbolo`, `id_empresa`, `id_mercado`) VALUES
(1, 'Apple Inc.', 'Accion', 'AAPL', 1, 2),
(2, 'Microsoft Corporation', 'Accion', 'MSFT', 2, 2),
(3, 'Amazon.com Inc.', 'Accion', 'AMZN', 3, 2),
(4, 'Alphabet Inc.', 'Accion', 'GOOGL', 4, 2),
(5, 'Ecopetrol S.A.', 'Accion', 'ECOPETROL', 5, 3),
(6, 'Toyota Motor', 'Accion', 'TM', 6, 1),
(7, 'Samsung Electronics', 'Accion', 'SMSN', 7, 4),
(8, 'Coca Cola Company', 'Accion', 'KO', 8, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alertas`
--

CREATE TABLE `alertas` (
  `id_alerta` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_activo` int(11) NOT NULL,
  `precio_objetivo` decimal(15,2) NOT NULL,
  `tipo_alerta` varchar(30) DEFAULT NULL,
  `estado` varchar(30) DEFAULT 'Activa',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `alertas`
--

INSERT INTO `alertas` (`id_alerta`, `id_usuario`, `id_activo`, `precio_objetivo`, `tipo_alerta`, `estado`, `fecha_creacion`) VALUES
(1, 1, 1, 250.00, 'Mayor que', 'Activa', '2026-11-04 16:10:40'),
(2, 1, 2, 400.00, 'Menor que', 'Activa', '2026-11-04 16:10:40'),
(3, 2, 3, 200.00, 'Mayor que', 'Activa', '2026-11-04 16:10:40'),
(4, 3, 5, 2000.00, 'Mayor que', 'Activa', '2026-11-04 16:10:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carteras_virtuales`
--

CREATE TABLE `carteras_virtuales` (
  `id_cartera` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `saldo_virtual` decimal(15,2) DEFAULT 100000.00,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `carteras_virtuales`
--

INSERT INTO `carteras_virtuales` (`id_cartera`, `id_usuario`, `nombre`, `saldo_virtual`, `fecha_creacion`) VALUES
(1, 1, 'Mi cartera principal', 100000.00, '2026-11-04 16:10:40'),
(2, 2, 'Cartera tecnologica', 80000.00, '2026-11-04 16:10:40'),
(3, 3, 'Cartera internacional', 120000.00, '2026-11-04 16:10:40'),
(4, 4, 'Mi primera cartera', 50000.00, '2026-11-04 16:10:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_cartera`
--

CREATE TABLE `detalle_cartera` (
  `id_detalle` int(11) NOT NULL,
  `id_cartera` int(11) NOT NULL,
  `id_activo` int(11) NOT NULL,
  `cantidad` decimal(15,4) NOT NULL,
  `precio_compra` decimal(15,2) NOT NULL,
  `fecha_compra` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_cartera`
--

INSERT INTO `detalle_cartera` (`id_detalle`, `id_cartera`, `id_activo`, `cantidad`, `precio_compra`, `fecha_compra`) VALUES
(1, 1, 1, 10.0000, 225.50, '2026-11-04 16:10:40'),
(2, 1, 2, 5.0000, 410.20, '2026-11-04 16:10:40'),
(3, 2, 3, 8.0000, 195.30, '2026-11-04 16:10:40'),
(4, 2, 4, 6.0000, 175.40, '2026-11-04 16:10:40'),
(5, 3, 5, 20.0000, 1850.00, '2026-11-04 16:10:40'),
(6, 3, 6, 4.0000, 195.00, '2026-11-04 16:10:40'),
(7, 4, 7, 10.0000, 65.50, '2026-11-04 16:10:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas`
--

CREATE TABLE `empresas` (
  `id_empresa` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `sector` varchar(100) DEFAULT NULL,
  `pais` varchar(100) DEFAULT NULL,
  `simbolo` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empresas`
--

INSERT INTO `empresas` (`id_empresa`, `nombre`, `sector`, `pais`, `simbolo`) VALUES
(1, 'Apple', 'Tecnologia', 'Estados Unidos', 'AAPL'),
(2, 'Microsoft', 'Tecnologia y servicios', 'Estados Unidos', 'MSFT'),
(3, 'Amazon', 'Comercio', 'Estados Unidos', 'AMZN'),
(4, 'Google', 'Tecnologia', 'Estados Unidos', 'GOOGL'),
(5, 'Ecopetrol', 'Energia', 'Colombia', 'ECOPETROL'),
(6, 'Toyota', 'Automotriz', 'Japon', 'TM'),
(7, 'Samsung', 'Tecnologia', 'Corea del Sur', 'SMSN'),
(8, 'Coca Cola', 'Alimentos', 'Estados Unidos', 'KO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `favoritos`
--

CREATE TABLE `favoritos` (
  `id_favorito` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_activo` int(11) NOT NULL,
  `fecha_agregado` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `favoritos`
--

INSERT INTO `favoritos` (`id_favorito`, `id_usuario`, `id_activo`, `fecha_agregado`) VALUES
(1, 1, 1, '2026-11-04 16:10:40'),
(2, 1, 2, '2026-11-04 16:10:40'),
(3, 1, 5, '2026-11-04 16:10:40'),
(4, 2, 3, '2026-11-04 16:10:40'),
(5, 2, 4, '2026-11-04 16:10:40'),
(6, 3, 6, '2026-11-04 16:10:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mercados`
--

CREATE TABLE `mercados` (
  `id_mercado` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `pais` varchar(100) NOT NULL,
  `ciudad` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mercados`
--

INSERT INTO `mercados` (`id_mercado`, `nombre`, `pais`, `ciudad`) VALUES
(1, 'NYSE', 'Estados Unidos', 'Nueva York'),
(2, 'NASDAQ', 'Estados Unidos', 'Nueva York'),
(3, 'Bolsa de Valores de Colombia', 'Colombia', 'Bogota'),
(4, 'Bolsa de Tokio', 'Japon', 'Tokio'),
(5, 'Bolsa de Londres', 'Reino Unido', 'Londres');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `monedas`
--

CREATE TABLE `monedas` (
  `id_moneda` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `codigo` varchar(10) NOT NULL,
  `simbolo` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `monedas`
--

INSERT INTO `monedas` (`id_moneda`, `nombre`, `codigo`, `simbolo`) VALUES
(1, 'Dolar estadounidense', 'USD', '$'),
(2, 'Peso colombiano', 'COP', '$'),
(3, 'Euro', 'EUR', '€'),
(4, 'Libra esterlina', 'GBP', '£'),
(5, 'Yen japones', 'JPY', '¥');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--

CREATE TABLE `noticias` (
  `id_noticia` int(11) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `fuente` varchar(100) DEFAULT NULL,
  `fecha_publicacion` datetime DEFAULT current_timestamp(),
  `id_empresa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `noticias`
--

INSERT INTO `noticias` (`id_noticia`, `titulo`, `descripcion`, `fuente`, `fecha_publicacion`, `id_empresa`) VALUES
(1, 'Apple presenta nuevos avances tecnologicos', 'La empresa anuncia mejoras en sus productos.', 'Noticias Financieras', '2026-11-04 11:10:40', 1),
(2, 'Microsoft fortalece sus servicios digitales', 'La compania presenta nuevas herramientas.', 'Economia Global', '2026-11-04 11:10:40', 2),
(3, 'Amazon amplia sus operaciones internacionales', 'La empresa busca fortalecer su comercio.', 'Mercados Internacionales', '2026-11-04 11:10:40', 3),
(4, 'Google anuncia nuevos proyectos de inteligencia artificial', 'La empresa presenta avances tecnologicos.', 'Tecnologia Hoy', '2026-11-04 11:10:40', 4),
(5, 'Ecopetrol informa resultados empresariales', 'La compania presenta sus resultados financieros.', 'Noticias Colombia', '2026-11-04 11:10:40', 5),
(6, 'Toyota presenta nuevos modelos de vehiculos', 'La empresa anuncia novedades en el sector automotriz.', 'Economia Mundial', '2026-11-04 11:10:40', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `precios_historicos`
--

CREATE TABLE `precios_historicos` (
  `id_precio` int(11) NOT NULL,
  `id_activo` int(11) NOT NULL,
  `precio` decimal(15,2) NOT NULL,
  `fecha` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `precios_historicos`
--

INSERT INTO `precios_historicos` (`id_precio`, `id_activo`, `precio`, `fecha`) VALUES
(1, 1, 225.50, '2026-10-01 10:00:00'),
(2, 1, 230.75, '2026-10-02 10:00:00'),
(3, 2, 410.20, '2026-10-01 10:00:00'),
(4, 2, 415.80, '2026-10-02 10:00:00'),
(5, 3, 195.30, '2026-10-01 10:00:00'),
(6, 3, 198.50, '2026-10-02 10:00:00'),
(7, 4, 175.40, '2026-10-01 10:00:00'),
(8, 4, 180.20, '2026-10-02 10:00:00'),
(9, 5, 1850.00, '2026-10-01 10:00:00'),
(10, 5, 1900.00, '2026-10-02 10:00:00'),
(11, 6, 195.00, '2026-10-01 10:00:00'),
(12, 6, 200.00, '2026-10-02 10:00:00'),
(13, 7, 65.50, '2026-10-01 10:00:00'),
(14, 7, 68.00, '2026-10-02 10:00:00'),
(15, 8, 70.20, '2026-10-01 10:00:00'),
(16, 8, 72.50, '2026-10-02 10:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tasas_cambio`
--

CREATE TABLE `tasas_cambio` (
  `id_tasa` int(11) NOT NULL,
  `id_moneda_origen` int(11) NOT NULL,
  `id_moneda_destino` int(11) NOT NULL,
  `tasa` decimal(15,6) NOT NULL,
  `fecha` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tasas_cambio`
--

INSERT INTO `tasas_cambio` (`id_tasa`, `id_moneda_origen`, `id_moneda_destino`, `tasa`, `fecha`) VALUES
(1, 1, 2, 4000.000000, '2026-11-04 11:10:40'),
(2, 1, 3, 0.920000, '2026-11-04 11:10:40'),
(3, 1, 4, 0.790000, '2026-11-04 11:10:40'),
(4, 1, 5, 150.000000, '2026-11-04 11:10:40'),
(5, 2, 1, 0.000250, '2026-11-04 11:10:40'),
(6, 3, 1, 1.087000, '2026-11-04 11:10:40'),
(7, 4, 1, 1.265000, '2026-11-04 11:10:40'),
(8, 5, 1, 0.006670, '2026-11-04 11:10:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `correo`, `contrasena`, `fecha_registro`) VALUES
(1, 'Juan David Cuervo', 'juan@gmail.com', '123456', '2026-11-04 16:10:40'),
(2, 'Maria Lopez', 'maria@gmail.com', '123456', '2026-11-04 16:10:40'),
(3, 'Carlos Perez', 'carlos@gmail.com', '123456', '2026-11-04 16:10:40'),
(4, 'Laura Gomez', 'laura@gmail.com', '123456', '2026-11-04 16:10:40');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `activos`
--
ALTER TABLE `activos`
  ADD PRIMARY KEY (`id_activo`),
  ADD KEY `id_empresa` (`id_empresa`),
  ADD KEY `id_mercado` (`id_mercado`);

--
-- Indices de la tabla `alertas`
--
ALTER TABLE `alertas`
  ADD PRIMARY KEY (`id_alerta`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_activo` (`id_activo`);

--
-- Indices de la tabla `carteras_virtuales`
--
ALTER TABLE `carteras_virtuales`
  ADD PRIMARY KEY (`id_cartera`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `detalle_cartera`
--
ALTER TABLE `detalle_cartera`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `id_cartera` (`id_cartera`),
  ADD KEY `id_activo` (`id_activo`);

--
-- Indices de la tabla `empresas`
--
ALTER TABLE `empresas`
  ADD PRIMARY KEY (`id_empresa`),
  ADD UNIQUE KEY `simbolo` (`simbolo`);

--
-- Indices de la tabla `favoritos`
--
ALTER TABLE `favoritos`
  ADD PRIMARY KEY (`id_favorito`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_activo` (`id_activo`);

--
-- Indices de la tabla `mercados`
--
ALTER TABLE `mercados`
  ADD PRIMARY KEY (`id_mercado`);

--
-- Indices de la tabla `monedas`
--
ALTER TABLE `monedas`
  ADD PRIMARY KEY (`id_moneda`),
  ADD UNIQUE KEY `codigo` (`codigo`);

--
-- Indices de la tabla `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`id_noticia`),
  ADD KEY `id_empresa` (`id_empresa`);

--
-- Indices de la tabla `precios_historicos`
--
ALTER TABLE `precios_historicos`
  ADD PRIMARY KEY (`id_precio`),
  ADD KEY `id_activo` (`id_activo`);

--
-- Indices de la tabla `tasas_cambio`
--
ALTER TABLE `tasas_cambio`
  ADD PRIMARY KEY (`id_tasa`),
  ADD KEY `id_moneda_origen` (`id_moneda_origen`),
  ADD KEY `id_moneda_destino` (`id_moneda_destino`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `activos`
--
ALTER TABLE `activos`
  MODIFY `id_activo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `alertas`
--
ALTER TABLE `alertas`
  MODIFY `id_alerta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `carteras_virtuales`
--
ALTER TABLE `carteras_virtuales`
  MODIFY `id_cartera` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `detalle_cartera`
--
ALTER TABLE `detalle_cartera`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `empresas`
--
ALTER TABLE `empresas`
  MODIFY `id_empresa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `favoritos`
--
ALTER TABLE `favoritos`
  MODIFY `id_favorito` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `mercados`
--
ALTER TABLE `mercados`
  MODIFY `id_mercado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `monedas`
--
ALTER TABLE `monedas`
  MODIFY `id_moneda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `noticias`
--
ALTER TABLE `noticias`
  MODIFY `id_noticia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `precios_historicos`
--
ALTER TABLE `precios_historicos`
  MODIFY `id_precio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `tasas_cambio`
--
ALTER TABLE `tasas_cambio`
  MODIFY `id_tasa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `activos`
--
ALTER TABLE `activos`
  ADD CONSTRAINT `activos_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `empresas` (`id_empresa`),
  ADD CONSTRAINT `activos_ibfk_2` FOREIGN KEY (`id_mercado`) REFERENCES `mercados` (`id_mercado`);

--
-- Filtros para la tabla `alertas`
--
ALTER TABLE `alertas`
  ADD CONSTRAINT `alertas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `alertas_ibfk_2` FOREIGN KEY (`id_activo`) REFERENCES `activos` (`id_activo`);

--
-- Filtros para la tabla `carteras_virtuales`
--
ALTER TABLE `carteras_virtuales`
  ADD CONSTRAINT `carteras_virtuales_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `detalle_cartera`
--
ALTER TABLE `detalle_cartera`
  ADD CONSTRAINT `detalle_cartera_ibfk_1` FOREIGN KEY (`id_cartera`) REFERENCES `carteras_virtuales` (`id_cartera`),
  ADD CONSTRAINT `detalle_cartera_ibfk_2` FOREIGN KEY (`id_activo`) REFERENCES `activos` (`id_activo`);

--
-- Filtros para la tabla `favoritos`
--
ALTER TABLE `favoritos`
  ADD CONSTRAINT `favoritos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `favoritos_ibfk_2` FOREIGN KEY (`id_activo`) REFERENCES `activos` (`id_activo`);

--
-- Filtros para la tabla `noticias`
--
ALTER TABLE `noticias`
  ADD CONSTRAINT `noticias_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `empresas` (`id_empresa`);

--
-- Filtros para la tabla `precios_historicos`
--
ALTER TABLE `precios_historicos`
  ADD CONSTRAINT `precios_historicos_ibfk_1` FOREIGN KEY (`id_activo`) REFERENCES `activos` (`id_activo`);

--
-- Filtros para la tabla `tasas_cambio`
--
ALTER TABLE `tasas_cambio`
  ADD CONSTRAINT `tasas_cambio_ibfk_1` FOREIGN KEY (`id_moneda_origen`) REFERENCES `monedas` (`id_moneda`),
  ADD CONSTRAINT `tasas_cambio_ibfk_2` FOREIGN KEY (`id_moneda_destino`) REFERENCES `monedas` (`id_moneda`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
