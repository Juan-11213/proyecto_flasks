from flask import Flask, render_template

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/servicios")
def servicios():
    servicios = [
        {"nombre": "Desarrollo web", "descripcion": "Sitios y aplicaciones web con Flask y Python."},
        {"nombre": "Diseño de interfaces", "descripcion": "Interfaces claras y responsivas con HTML y CSS."},
        {"nombre": "Bases de datos", "descripcion": "Modelado y consulta de bases de datos relacionales."},
    ]
    return render_template("servicios.html", servicios=servicios)


@app.route("/contacto")
def contacto():
    return render_template("contacto.html")


if __name__ == "__main__":
    app.run(debug=True)
