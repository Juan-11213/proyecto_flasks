# Prototipo web modular con Flask y HTML

Proyecto de la asignatura **Fundamentos de programación web** (UNIMINUTO).
Aplicación Flask con tres páginas (Inicio, Servicios, Contacto) construidas sobre una
plantilla base con Jinja2 (`extends`, `block` e `include`).

## Estructura

```
proyecto_flask/
├── app.py
├── requirements.txt
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── servicios.html
│   ├── contacto.html
│   └── includes/
│       ├── header.html
│       ├── navbar.html
│       └── footer.html
└── static/css/estilos.css
```

## Requisitos

- Python 3.9 o superior
- pip

## Instalación

```bash
git clone <URL_DEL_REPOSITORIO>
cd proyecto_flask

python -m venv venv
# Windows
venv\Scripts\activate
# Linux / macOS
source venv/bin/activate

pip install -r requirements.txt
```

## Ejecución

```bash
python app.py
```

Abre <http://127.0.0.1:5000> en el navegador.

## Rutas

| Ruta         | Página    |
|--------------|-----------|
| `/`          | Inicio    |
| `/servicios` | Servicios |
| `/contacto`  | Contacto  |

## Conceptos aplicados

- `{% extends "base.html" %}` en cada página.
- `{% block title %}` y `{% block content %}` definidos en `base.html`.
- `{% include %}` para header, navbar y footer.
- `url_for('static', ...)` para enlazar el CSS.

## Autores

- Nombre 1
- Nombre 2
